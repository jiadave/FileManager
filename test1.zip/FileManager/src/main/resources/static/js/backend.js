function myfunction() {
    var input_value = document.getElementById("input").value
    alert("You wrote " + input_value);
}